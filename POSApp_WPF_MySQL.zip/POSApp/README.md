# POS System - WPF + MySQL

A full-featured Point of Sale and Inventory Management desktop application built with C# WPF and MySQL.

## Features
- **Sales / Checkout** - Cart system, barcode scanning, payment processing, change calculation
- **Inventory Management** - Products, categories, stock adjustments, low-stock alerts
- **Customer Management** - Customer database, loyalty points
- **Reports & Analytics** - Sales history, revenue summaries, category breakdown, low stock report
- **User Management** - Role-based access (Admin, Manager, Cashier), password management

## Requirements
- Windows 10/11
- .NET 8.0 SDK — https://dotnet.microsoft.com/download/dotnet/8
- MySQL Server 8.0+ (local or remote)
- MySQL user with CREATE TABLE permissions

## Quick Start

### 1. Install .NET 8
Download and install from: https://dotnet.microsoft.com/download/dotnet/8

### 2. Set Up MySQL
```sql
CREATE DATABASE pos_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
(The app will auto-create all tables on first login.)

### 3. Build & Run
```bash
cd POSApp
dotnet restore
dotnet run
```

Or build a release executable:
```bash
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```
The .exe will be in `bin/Release/net8.0-windows/win-x64/publish/`

## Default Login
- **Username:** admin
- **Password:** admin123

## Database Settings
On the login screen, expand "Database Settings" and enter:
- Server: `localhost` (or your MySQL server IP)
- Port: `3306`
- Database: `pos_db`
- DB User: your MySQL username
- DB Password: your MySQL password

## Project Structure
```
POSApp/
├── Data/
│   └── DatabaseManager.cs      # MySQL connection & schema
├── Models/
│   └── Models.cs               # All data models
├── Services/
│   └── Services.cs             # Business logic & data access
├── Views/
│   ├── LoginWindow.xaml(.cs)   # Login screen
│   ├── MainWindow.xaml(.cs)    # Main shell with sidebar
│   ├── DashboardPage.xaml(.cs) # Dashboard with stats & charts
│   ├── SalesPage.xaml(.cs)     # POS checkout
│   ├── InventoryPage.xaml(.cs) # Product management
│   ├── CustomersPage.xaml(.cs) # Customer management
│   ├── ReportsPage.xaml(.cs)   # Reports & analytics
│   ├── UsersPage.xaml(.cs)     # User management (Admin only)
│   ├── ProductDialog.xaml(.cs) # Add/edit product
│   ├── CustomerDialog.xaml(.cs)# Add/edit customer
│   ├── UserDialog.xaml(.cs)    # Add/edit user
│   ├── StockAdjustDialog.xaml(.cs) # Stock adjustments
│   └── CategoriesDialog.xaml(.cs) # Category management
├── App.xaml(.cs)               # App entry point & styles
└── POSApp.csproj               # Project file
```

## User Roles
| Feature | Cashier | Manager | Admin |
|---------|---------|---------|-------|
| POS / Sales | ✅ | ✅ | ✅ |
| View Inventory | ✅ | ✅ | ✅ |
| Edit Products | ❌ | ✅ | ✅ |
| Reports | ✅ | ✅ | ✅ |
| User Management | ❌ | ❌ | ✅ |

## Extending the App
- **Receipt printing**: Add a PrintDialog in SalesPage after processing sale
- **Barcode generation**: Use `ZXing.Net` NuGet package
- **Excel export**: Use `ClosedXML` NuGet package for reports
- **Email receipts**: Use `MailKit` NuGet package
