namespace POSApp.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        public string Role { get; set; } = "Cashier";
        public string FullName { get; set; } = "";
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; }
    }

    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string? Description { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string? Barcode { get; set; }
        public int? CategoryId { get; set; }
        public string CategoryName { get; set; } = "";
        public decimal CostPrice { get; set; }
        public decimal SalePrice { get; set; }
        public int StockQuantity { get; set; }
        public int LowStockThreshold { get; set; } = 10;
        public string Unit { get; set; } = "pcs";
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; }
        public bool IsLowStock => StockQuantity <= LowStockThreshold;
    }

    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
        public int LoyaltyPoints { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class CartItem
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = "";
        public decimal UnitPrice { get; set; }
        public int Quantity { get; set; }
        public decimal Discount { get; set; }
        public decimal Subtotal => (UnitPrice * Quantity) - Discount;
        public string Unit { get; set; } = "pcs";
    }

    public class Sale
    {
        public int Id { get; set; }
        public string InvoiceNumber { get; set; } = "";
        public int? CustomerId { get; set; }
        public string CustomerName { get; set; } = "";
        public int UserId { get; set; }
        public string CashierName { get; set; } = "";
        public decimal Subtotal { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal Change { get; set; }
        public string PaymentMethod { get; set; } = "Cash";
        public string? Notes { get; set; }
        public DateTime SaleDate { get; set; }
        public List<SaleItem> Items { get; set; } = new();
    }

    public class SaleItem
    {
        public int Id { get; set; }
        public int SaleId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; } = "";
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Discount { get; set; }
        public decimal Subtotal { get; set; }
    }

    public class StockMovement
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; } = "";
        public int? UserId { get; set; }
        public string MovementType { get; set; } = "";
        public int Quantity { get; set; }
        public string? Notes { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class DashboardStats
    {
        public decimal TodaySales { get; set; }
        public int TodayTransactions { get; set; }
        public int TotalProducts { get; set; }
        public int LowStockCount { get; set; }
        public decimal MonthSales { get; set; }
        public List<(string Date, decimal Amount)> WeeklySales { get; set; } = new();
        public List<(string Product, int Qty)> TopProducts { get; set; } = new();
    }
}
