using MySql.Data.MySqlClient;

namespace POSApp.Data
{
    public class DatabaseManager
    {
        private static string _connectionString = "";

        public static void Initialize(string server, string database, string user, string password, string port = "3306")
        {
            _connectionString = $"Server={server};Port={port};Database={database};Uid={user};Pwd={password};CharSet=utf8mb4;";
        }

        public static MySqlConnection GetConnection()
        {
            var conn = new MySqlConnection(_connectionString);
            conn.Open();
            return conn;
        }

        public static void CreateSchema()
        {
            using var conn = GetConnection();

            var sql = @"
CREATE TABLE IF NOT EXISTS Users (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50) UNIQUE NOT NULL,
    PasswordHash VARCHAR(255) NOT NULL,
    Role ENUM('Admin','Cashier','Manager') NOT NULL DEFAULT 'Cashier',
    FullName VARCHAR(100),
    IsActive BOOLEAN DEFAULT TRUE,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS Categories (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Description TEXT
);

CREATE TABLE IF NOT EXISTS Products (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(200) NOT NULL,
    Barcode VARCHAR(100) UNIQUE,
    CategoryId INT,
    CostPrice DECIMAL(10,2) NOT NULL DEFAULT 0,
    SalePrice DECIMAL(10,2) NOT NULL DEFAULT 0,
    StockQuantity INT NOT NULL DEFAULT 0,
    LowStockThreshold INT DEFAULT 10,
    Unit VARCHAR(20) DEFAULT 'pcs',
    IsActive BOOLEAN DEFAULT TRUE,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (CategoryId) REFERENCES Categories(Id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS Customers (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(150) NOT NULL,
    Phone VARCHAR(30),
    Email VARCHAR(150),
    Address TEXT,
    LoyaltyPoints INT DEFAULT 0,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS Sales (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    InvoiceNumber VARCHAR(50) UNIQUE NOT NULL,
    CustomerId INT,
    UserId INT NOT NULL,
    Subtotal DECIMAL(10,2) NOT NULL,
    DiscountAmount DECIMAL(10,2) DEFAULT 0,
    TaxAmount DECIMAL(10,2) DEFAULT 0,
    TotalAmount DECIMAL(10,2) NOT NULL,
    AmountPaid DECIMAL(10,2) NOT NULL,
    Change DECIMAL(10,2) DEFAULT 0,
    PaymentMethod ENUM('Cash','Card','Mobile') DEFAULT 'Cash',
    Notes TEXT,
    SaleDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (CustomerId) REFERENCES Customers(Id) ON DELETE SET NULL,
    FOREIGN KEY (UserId) REFERENCES Users(Id)
);

CREATE TABLE IF NOT EXISTS SaleItems (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    SaleId INT NOT NULL,
    ProductId INT NOT NULL,
    ProductName VARCHAR(200) NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(10,2) NOT NULL,
    Discount DECIMAL(10,2) DEFAULT 0,
    Subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (SaleId) REFERENCES Sales(Id) ON DELETE CASCADE,
    FOREIGN KEY (ProductId) REFERENCES Products(Id)
);

CREATE TABLE IF NOT EXISTS StockMovements (
    Id INT AUTO_INCREMENT PRIMARY KEY,
    ProductId INT NOT NULL,
    UserId INT,
    MovementType ENUM('Purchase','Sale','Adjustment','Return') NOT NULL,
    Quantity INT NOT NULL,
    Notes TEXT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ProductId) REFERENCES Products(Id),
    FOREIGN KEY (UserId) REFERENCES Users(Id)
);

INSERT IGNORE INTO Users (Username, PasswordHash, Role, FullName)
VALUES ('admin', '$2a$11$RlJVtTSMQC0T8cZYQYd6yObmXKBsFexTxNOjwHLh6jHfIPUBxnmJq', 'Admin', 'System Administrator');

INSERT IGNORE INTO Categories (Name, Description) VALUES 
    ('General', 'General products'),
    ('Food & Beverage', 'Food and drink items'),
    ('Electronics', 'Electronic items');
";
            // Note: default admin password is 'admin123'
            using var cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
        }
    }
}
