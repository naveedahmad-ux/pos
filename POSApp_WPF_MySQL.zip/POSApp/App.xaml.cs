using System.Windows;

namespace POSApp
{
    public partial class App : Application
    {
    }
}
