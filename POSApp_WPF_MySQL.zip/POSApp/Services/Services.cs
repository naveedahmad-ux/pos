using MySql.Data.MySqlClient;
using POSApp.Data;
using POSApp.Models;
using BCrypt.Net;

namespace POSApp.Services
{
    public class AuthService
    {
        public static User? CurrentUser { get; private set; }

        public static User? Login(string username, string password)
        {
            using var conn = DatabaseManager.GetConnection();
            var cmd = new MySqlCommand("SELECT * FROM Users WHERE Username=@u AND IsActive=1", conn);
            cmd.Parameters.AddWithValue("@u", username);
            using var r = cmd.ExecuteReader();
            if (!r.Read()) return null;

            var hash = r.GetString("PasswordHash");
            if (!BCrypt.Net.BCrypt.Verify(password, hash)) return null;

            CurrentUser = new User
            {
                Id = r.GetInt32("Id"),
                Username = r.GetString("Username"),
                Role = r.GetString("Role"),
                FullName = r.GetString("FullName"),
                IsActive = r.GetBoolean("IsActive")
            };
            return CurrentUser;
        }

        public static void Logout() => CurrentUser = null;
        public static bool IsAdmin => CurrentUser?.Role == "Admin";
        public static bool IsManager => CurrentUser?.Role is "Admin" or "Manager";
    }

    public class ProductService
    {
        public static List<Product> GetAll(string search = "", int categoryId = 0, bool activeOnly = true)
        {
            var list = new List<Product>();
            using var conn = DatabaseManager.GetConnection();
            var sql = @"SELECT p.*, c.Name AS CategoryName FROM Products p
                        LEFT JOIN Categories c ON p.CategoryId = c.Id
                        WHERE 1=1";
            if (activeOnly) sql += " AND p.IsActive=1";
            if (!string.IsNullOrEmpty(search)) sql += " AND (p.Name LIKE @s OR p.Barcode LIKE @s)";
            if (categoryId > 0) sql += " AND p.CategoryId=@cat";
            sql += " ORDER BY p.Name";

            using var cmd = new MySqlCommand(sql, conn);
            if (!string.IsNullOrEmpty(search)) cmd.Parameters.AddWithValue("@s", $"%{search}%");
            if (categoryId > 0) cmd.Parameters.AddWithValue("@cat", categoryId);
            using var r = cmd.ExecuteReader();
            while (r.Read())
                list.Add(MapProduct(r));
            return list;
        }

        public static Product? GetByBarcode(string barcode)
        {
            using var conn = DatabaseManager.GetConnection();
            var cmd = new MySqlCommand("SELECT p.*, c.Name AS CategoryName FROM Products p LEFT JOIN Categories c ON p.CategoryId=c.Id WHERE p.Barcode=@b AND p.IsActive=1", conn);
            cmd.Parameters.AddWithValue("@b", barcode);
            using var r = cmd.ExecuteReader();
            return r.Read() ? MapProduct(r) : null;
        }

        public static void Save(Product p)
        {
            using var conn = DatabaseManager.GetConnection();
            if (p.Id == 0)
            {
                var cmd = new MySqlCommand(@"INSERT INTO Products (Name,Barcode,CategoryId,CostPrice,SalePrice,StockQuantity,LowStockThreshold,Unit,IsActive)
                    VALUES (@n,@b,@c,@cp,@sp,@sq,@ls,@u,@a)", conn);
                BindProduct(cmd, p);
                cmd.ExecuteNonQuery();
            }
            else
            {
                var cmd = new MySqlCommand(@"UPDATE Products SET Name=@n,Barcode=@b,CategoryId=@c,CostPrice=@cp,SalePrice=@sp,
                    StockQuantity=@sq,LowStockThreshold=@ls,Unit=@u,IsActive=@a WHERE Id=@id", conn);
                BindProduct(cmd, p);
                cmd.Parameters.AddWithValue("@id", p.Id);
                cmd.ExecuteNonQuery();
            }
        }

        private static void BindProduct(MySqlCommand cmd, Product p)
        {
            cmd.Parameters.AddWithValue("@n", p.Name);
            cmd.Parameters.AddWithValue("@b", (object?)p.Barcode ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@c", (object?)p.CategoryId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@cp", p.CostPrice);
            cmd.Parameters.AddWithValue("@sp", p.SalePrice);
            cmd.Parameters.AddWithValue("@sq", p.StockQuantity);
            cmd.Parameters.AddWithValue("@ls", p.LowStockThreshold);
            cmd.Parameters.AddWithValue("@u", p.Unit);
            cmd.Parameters.AddWithValue("@a", p.IsActive);
        }

        public static void AdjustStock(int productId, int qty, string type, string notes, int userId)
        {
            using var conn = DatabaseManager.GetConnection();
            using var tx = conn.BeginTransaction();
            var cmd1 = new MySqlCommand("UPDATE Products SET StockQuantity=StockQuantity+@q WHERE Id=@id", conn, tx);
            cmd1.Parameters.AddWithValue("@q", qty);
            cmd1.Parameters.AddWithValue("@id", productId);
            cmd1.ExecuteNonQuery();

            var cmd2 = new MySqlCommand("INSERT INTO StockMovements (ProductId,UserId,MovementType,Quantity,Notes) VALUES (@p,@u,@t,@q,@n)", conn, tx);
            cmd2.Parameters.AddWithValue("@p", productId);
            cmd2.Parameters.AddWithValue("@u", userId);
            cmd2.Parameters.AddWithValue("@t", type);
            cmd2.Parameters.AddWithValue("@q", qty);
            cmd2.Parameters.AddWithValue("@n", notes);
            cmd2.ExecuteNonQuery();
            tx.Commit();
        }

        private static Product MapProduct(MySqlDataReader r) => new()
        {
            Id = r.GetInt32("Id"),
            Name = r.GetString("Name"),
            Barcode = r.IsDBNull(r.GetOrdinal("Barcode")) ? null : r.GetString("Barcode"),
            CategoryId = r.IsDBNull(r.GetOrdinal("CategoryId")) ? null : r.GetInt32("CategoryId"),
            CategoryName = r.IsDBNull(r.GetOrdinal("CategoryName")) ? "" : r.GetString("CategoryName"),
            CostPrice = r.GetDecimal("CostPrice"),
            SalePrice = r.GetDecimal("SalePrice"),
            StockQuantity = r.GetInt32("StockQuantity"),
            LowStockThreshold = r.GetInt32("LowStockThreshold"),
            Unit = r.GetString("Unit"),
            IsActive = r.GetBoolean("IsActive")
        };
    }

    public class CategoryService
    {
        public static List<Category> GetAll()
        {
            var list = new List<Category>();
            using var conn = DatabaseManager.GetConnection();
            using var cmd = new MySqlCommand("SELECT * FROM Categories ORDER BY Name", conn);
            using var r = cmd.ExecuteReader();
            while (r.Read())
                list.Add(new Category { Id = r.GetInt32("Id"), Name = r.GetString("Name"), Description = r.IsDBNull(r.GetOrdinal("Description")) ? null : r.GetString("Description") });
            return list;
        }

        public static void Save(Category c)
        {
            using var conn = DatabaseManager.GetConnection();
            if (c.Id == 0)
            {
                var cmd = new MySqlCommand("INSERT INTO Categories (Name,Description) VALUES (@n,@d)", conn);
                cmd.Parameters.AddWithValue("@n", c.Name);
                cmd.Parameters.AddWithValue("@d", (object?)c.Description ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }
            else
            {
                var cmd = new MySqlCommand("UPDATE Categories SET Name=@n,Description=@d WHERE Id=@id", conn);
                cmd.Parameters.AddWithValue("@n", c.Name);
                cmd.Parameters.AddWithValue("@d", (object?)c.Description ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@id", c.Id);
                cmd.ExecuteNonQuery();
            }
        }

        public static void Delete(int id)
        {
            using var conn = DatabaseManager.GetConnection();
            var cmd = new MySqlCommand("DELETE FROM Categories WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            cmd.ExecuteNonQuery();
        }
    }

    public class SaleService
    {
        public static string GenerateInvoiceNumber()
        {
            return $"INV-{DateTime.Now:yyyyMMdd}-{new Random().Next(1000, 9999)}";
        }

        public static int ProcessSale(Sale sale, List<CartItem> items)
        {
            using var conn = DatabaseManager.GetConnection();
            using var tx = conn.BeginTransaction();

            var cmd = new MySqlCommand(@"INSERT INTO Sales (InvoiceNumber,CustomerId,UserId,Subtotal,DiscountAmount,TaxAmount,TotalAmount,AmountPaid,`Change`,PaymentMethod,Notes)
                VALUES (@inv,@cust,@uid,@sub,@disc,@tax,@total,@paid,@change,@pm,@notes)", conn, tx);
            cmd.Parameters.AddWithValue("@inv", sale.InvoiceNumber);
            cmd.Parameters.AddWithValue("@cust", (object?)sale.CustomerId ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@uid", sale.UserId);
            cmd.Parameters.AddWithValue("@sub", sale.Subtotal);
            cmd.Parameters.AddWithValue("@disc", sale.DiscountAmount);
            cmd.Parameters.AddWithValue("@tax", sale.TaxAmount);
            cmd.Parameters.AddWithValue("@total", sale.TotalAmount);
            cmd.Parameters.AddWithValue("@paid", sale.AmountPaid);
            cmd.Parameters.AddWithValue("@change", sale.Change);
            cmd.Parameters.AddWithValue("@pm", sale.PaymentMethod);
            cmd.Parameters.AddWithValue("@notes", (object?)sale.Notes ?? DBNull.Value);
            cmd.ExecuteNonQuery();
            int saleId = (int)cmd.LastInsertedId;

            foreach (var item in items)
            {
                var ic = new MySqlCommand(@"INSERT INTO SaleItems (SaleId,ProductId,ProductName,Quantity,UnitPrice,Discount,Subtotal)
                    VALUES (@sid,@pid,@pn,@qty,@up,@disc,@sub)", conn, tx);
                ic.Parameters.AddWithValue("@sid", saleId);
                ic.Parameters.AddWithValue("@pid", item.ProductId);
                ic.Parameters.AddWithValue("@pn", item.ProductName);
                ic.Parameters.AddWithValue("@qty", item.Quantity);
                ic.Parameters.AddWithValue("@up", item.UnitPrice);
                ic.Parameters.AddWithValue("@disc", item.Discount);
                ic.Parameters.AddWithValue("@sub", item.Subtotal);
                ic.ExecuteNonQuery();

                var sc = new MySqlCommand("UPDATE Products SET StockQuantity=StockQuantity-@q WHERE Id=@id", conn, tx);
                sc.Parameters.AddWithValue("@q", item.Quantity);
                sc.Parameters.AddWithValue("@id", item.ProductId);
                sc.ExecuteNonQuery();

                var sm = new MySqlCommand("INSERT INTO StockMovements (ProductId,UserId,MovementType,Quantity,Notes) VALUES (@p,@u,'Sale',@q,@n)", conn, tx);
                sm.Parameters.AddWithValue("@p", item.ProductId);
                sm.Parameters.AddWithValue("@u", sale.UserId);
                sm.Parameters.AddWithValue("@q", -item.Quantity);
                sm.Parameters.AddWithValue("@n", $"Sale {sale.InvoiceNumber}");
                sm.ExecuteNonQuery();
            }

            tx.Commit();
            return saleId;
        }

        public static List<Sale> GetSales(DateTime from, DateTime to, int userId = 0)
        {
            var list = new List<Sale>();
            using var conn = DatabaseManager.GetConnection();
            var sql = @"SELECT s.*, u.FullName AS CashierName, IFNULL(c.Name,'Walk-in') AS CustomerName
                        FROM Sales s LEFT JOIN Users u ON s.UserId=u.Id LEFT JOIN Customers c ON s.CustomerId=c.Id
                        WHERE s.SaleDate BETWEEN @f AND @t";
            if (userId > 0) sql += " AND s.UserId=@uid";
            sql += " ORDER BY s.SaleDate DESC";

            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@f", from.Date);
            cmd.Parameters.AddWithValue("@t", to.Date.AddDays(1));
            if (userId > 0) cmd.Parameters.AddWithValue("@uid", userId);
            using var r = cmd.ExecuteReader();
            while (r.Read())
                list.Add(new Sale
                {
                    Id = r.GetInt32("Id"),
                    InvoiceNumber = r.GetString("InvoiceNumber"),
                    CashierName = r.GetString("CashierName"),
                    CustomerName = r.GetString("CustomerName"),
                    TotalAmount = r.GetDecimal("TotalAmount"),
                    PaymentMethod = r.GetString("PaymentMethod"),
                    SaleDate = r.GetDateTime("SaleDate")
                });
            return list;
        }
    }

    public class CustomerService
    {
        public static List<Customer> GetAll(string search = "")
        {
            var list = new List<Customer>();
            using var conn = DatabaseManager.GetConnection();
            var sql = "SELECT * FROM Customers WHERE 1=1";
            if (!string.IsNullOrEmpty(search)) sql += " AND (Name LIKE @s OR Phone LIKE @s)";
            sql += " ORDER BY Name";
            using var cmd = new MySqlCommand(sql, conn);
            if (!string.IsNullOrEmpty(search)) cmd.Parameters.AddWithValue("@s", $"%{search}%");
            using var r = cmd.ExecuteReader();
            while (r.Read())
                list.Add(new Customer
                {
                    Id = r.GetInt32("Id"),
                    Name = r.GetString("Name"),
                    Phone = r.IsDBNull(r.GetOrdinal("Phone")) ? null : r.GetString("Phone"),
                    Email = r.IsDBNull(r.GetOrdinal("Email")) ? null : r.GetString("Email"),
                    LoyaltyPoints = r.GetInt32("LoyaltyPoints")
                });
            return list;
        }

        public static void Save(Customer c)
        {
            using var conn = DatabaseManager.GetConnection();
            if (c.Id == 0)
            {
                var cmd = new MySqlCommand("INSERT INTO Customers (Name,Phone,Email,Address) VALUES (@n,@p,@e,@a)", conn);
                cmd.Parameters.AddWithValue("@n", c.Name);
                cmd.Parameters.AddWithValue("@p", (object?)c.Phone ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@e", (object?)c.Email ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@a", (object?)c.Address ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }
            else
            {
                var cmd = new MySqlCommand("UPDATE Customers SET Name=@n,Phone=@p,Email=@e,Address=@a WHERE Id=@id", conn);
                cmd.Parameters.AddWithValue("@n", c.Name);
                cmd.Parameters.AddWithValue("@p", (object?)c.Phone ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@e", (object?)c.Email ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@a", (object?)c.Address ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@id", c.Id);
                cmd.ExecuteNonQuery();
            }
        }
    }

    public class ReportService
    {
        public static DashboardStats GetDashboardStats()
        {
            using var conn = DatabaseManager.GetConnection();
            var stats = new DashboardStats();

            var today = DateTime.Today;

            using (var cmd = new MySqlCommand("SELECT IFNULL(SUM(TotalAmount),0), COUNT(*) FROM Sales WHERE DATE(SaleDate)=@d", conn))
            {
                cmd.Parameters.AddWithValue("@d", today);
                using var r = cmd.ExecuteReader();
                if (r.Read()) { stats.TodaySales = r.GetDecimal(0); stats.TodayTransactions = r.GetInt32(1); }
            }

            using (var cmd = new MySqlCommand("SELECT COUNT(*) FROM Products WHERE IsActive=1", conn))
                stats.TotalProducts = Convert.ToInt32(cmd.ExecuteScalar());

            using (var cmd = new MySqlCommand("SELECT COUNT(*) FROM Products WHERE IsActive=1 AND StockQuantity<=LowStockThreshold", conn))
                stats.LowStockCount = Convert.ToInt32(cmd.ExecuteScalar());

            using (var cmd = new MySqlCommand("SELECT IFNULL(SUM(TotalAmount),0) FROM Sales WHERE MONTH(SaleDate)=MONTH(NOW()) AND YEAR(SaleDate)=YEAR(NOW())", conn))
                stats.MonthSales = Convert.ToDecimal(cmd.ExecuteScalar());

            using (var cmd = new MySqlCommand("SELECT DATE(SaleDate) AS D, SUM(TotalAmount) FROM Sales WHERE SaleDate >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(SaleDate) ORDER BY D", conn))
            {
                using var r = cmd.ExecuteReader();
                while (r.Read())
                    stats.WeeklySales.Add((r.GetDateTime(0).ToString("ddd"), r.GetDecimal(1)));
            }

            using (var cmd = new MySqlCommand("SELECT ProductName, SUM(Quantity) AS Q FROM SaleItems si JOIN Sales s ON si.SaleId=s.Id WHERE s.SaleDate >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY ProductId,ProductName ORDER BY Q DESC LIMIT 5", conn))
            {
                using var r = cmd.ExecuteReader();
                while (r.Read())
                    stats.TopProducts.Add((r.GetString(0), r.GetInt32(1)));
            }

            return stats;
        }

        public static List<(string Label, decimal Value)> GetSalesByCategory(DateTime from, DateTime to)
        {
            var list = new List<(string, decimal)>();
            using var conn = DatabaseManager.GetConnection();
            var sql = @"SELECT IFNULL(c.Name,'Uncategorized'), SUM(si.Subtotal)
                        FROM SaleItems si JOIN Products p ON si.ProductId=p.Id
                        LEFT JOIN Categories c ON p.CategoryId=c.Id
                        JOIN Sales s ON si.SaleId=s.Id
                        WHERE s.SaleDate BETWEEN @f AND @t
                        GROUP BY c.Id, c.Name ORDER BY 2 DESC";
            using var cmd = new MySqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@f", from.Date);
            cmd.Parameters.AddWithValue("@t", to.Date.AddDays(1));
            using var r = cmd.ExecuteReader();
            while (r.Read())
                list.Add((r.GetString(0), r.GetDecimal(1)));
            return list;
        }
    }

    public class UserService
    {
        public static List<User> GetAll()
        {
            var list = new List<User>();
            using var conn = DatabaseManager.GetConnection();
            using var cmd = new MySqlCommand("SELECT * FROM Users ORDER BY FullName", conn);
            using var r = cmd.ExecuteReader();
            while (r.Read())
                list.Add(new User
                {
                    Id = r.GetInt32("Id"),
                    Username = r.GetString("Username"),
                    Role = r.GetString("Role"),
                    FullName = r.GetString("FullName"),
                    IsActive = r.GetBoolean("IsActive")
                });
            return list;
        }

        public static void Save(User u, string? plainPassword = null)
        {
            using var conn = DatabaseManager.GetConnection();
            if (u.Id == 0)
            {
                var hash = BCrypt.Net.BCrypt.HashPassword(plainPassword ?? "password123");
                var cmd = new MySqlCommand("INSERT INTO Users (Username,PasswordHash,Role,FullName,IsActive) VALUES (@un,@ph,@r,@fn,@a)", conn);
                cmd.Parameters.AddWithValue("@un", u.Username);
                cmd.Parameters.AddWithValue("@ph", hash);
                cmd.Parameters.AddWithValue("@r", u.Role);
                cmd.Parameters.AddWithValue("@fn", u.FullName);
                cmd.Parameters.AddWithValue("@a", u.IsActive);
                cmd.ExecuteNonQuery();
            }
            else
            {
                if (!string.IsNullOrEmpty(plainPassword))
                {
                    var hash = BCrypt.Net.BCrypt.HashPassword(plainPassword);
                    var cmd = new MySqlCommand("UPDATE Users SET Username=@un,PasswordHash=@ph,Role=@r,FullName=@fn,IsActive=@a WHERE Id=@id", conn);
                    cmd.Parameters.AddWithValue("@un", u.Username);
                    cmd.Parameters.AddWithValue("@ph", hash);
                    cmd.Parameters.AddWithValue("@r", u.Role);
                    cmd.Parameters.AddWithValue("@fn", u.FullName);
                    cmd.Parameters.AddWithValue("@a", u.IsActive);
                    cmd.Parameters.AddWithValue("@id", u.Id);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    var cmd = new MySqlCommand("UPDATE Users SET Username=@un,Role=@r,FullName=@fn,IsActive=@a WHERE Id=@id", conn);
                    cmd.Parameters.AddWithValue("@un", u.Username);
                    cmd.Parameters.AddWithValue("@r", u.Role);
                    cmd.Parameters.AddWithValue("@fn", u.FullName);
                    cmd.Parameters.AddWithValue("@a", u.IsActive);
                    cmd.Parameters.AddWithValue("@id", u.Id);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
