using System.Windows;
using System.Windows.Controls;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class ReportsPage : Page
    {
        public ReportsPage()
        {
            InitializeComponent();
            DpFrom.SelectedDate = DateTime.Today.AddDays(-30);
            DpTo.SelectedDate = DateTime.Today;
            Loaded += (_, _) => GenerateReports();
        }

        private void BtnGenerate_Click(object sender, RoutedEventArgs e) => GenerateReports();

        private void GenerateReports()
        {
            var from = DpFrom.SelectedDate ?? DateTime.Today.AddDays(-30);
            var to = DpTo.SelectedDate ?? DateTime.Today;

            // Sales
            var sales = SaleService.GetSales(from, to);
            SalesGrid.ItemsSource = sales;

            // Summary
            var total = sales.Sum(s => s.TotalAmount);
            TxtRevenue.Text = total.ToString("C");
            TxtTransactions.Text = sales.Count.ToString();
            TxtAvgTx.Text = sales.Count > 0 ? (total / sales.Count).ToString("C") : "₱0.00";

            // Category breakdown
            var catData = ReportService.GetSalesByCategory(from, to)
                .Select(x => new { Category = x.Label, Total = x.Value }).ToList();
            CategoryGrid.ItemsSource = catData;

            // Low stock
            var lowStock = ProductService.GetAll("", 0, true).Where(p => p.IsLowStock).ToList();
            LowStockGrid.ItemsSource = lowStock;
        }
    }
}
