using System.Windows;
using System.Windows.Controls;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class StockAdjustDialog : Window
    {
        public StockAdjustDialog()
        {
            InitializeComponent();
            CbProduct.ItemsSource = ProductService.GetAll();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (CbProduct.SelectedValue == null) { MessageBox.Show("Please select a product."); return; }
            if (!int.TryParse(TxtQty.Text, out int qty)) { MessageBox.Show("Invalid quantity."); return; }

            var type = (CbType.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Adjustment";
            try
            {
                ProductService.AdjustStock((int)CbProduct.SelectedValue, qty, type, TxtNotes.Text, AuthService.CurrentUser!.Id);
                MessageBox.Show("Stock adjusted successfully!");
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
    }
}
