using System.Windows;
using POSApp.Models;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class CustomerDialog : Window
    {
        private Customer? _customer;

        public CustomerDialog(Customer? customer)
        {
            InitializeComponent();
            _customer = customer;
            if (customer != null)
            {
                TxtTitle.Text = "Edit Customer";
                TxtName.Text = customer.Name;
                TxtPhone.Text = customer.Phone;
                TxtEmail.Text = customer.Email;
                TxtAddress.Text = customer.Address;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtName.Text)) { MessageBox.Show("Name is required."); return; }
            var c = _customer ?? new Customer();
            c.Name = TxtName.Text.Trim();
            c.Phone = TxtPhone.Text.Trim();
            c.Email = TxtEmail.Text.Trim();
            c.Address = TxtAddress.Text.Trim();
            CustomerService.Save(c);
            DialogResult = true;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
    }
}
