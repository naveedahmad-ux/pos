using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using POSApp.Models;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class InventoryPage : Page
    {
        public InventoryPage()
        {
            InitializeComponent();
            Loaded += (_, _) => { LoadCategories(); LoadProducts(); };
        }

        private void LoadCategories()
        {
            CbCategory.Items.Clear();
            CbCategory.Items.Add(new ComboBoxItem { Content = "All Categories", Tag = 0 });
            foreach (var c in CategoryService.GetAll())
                CbCategory.Items.Add(new ComboBoxItem { Content = c.Name, Tag = c.Id });
            CbCategory.SelectedIndex = 0;
        }

        private void LoadProducts()
        {
            var search = TxtSearch.Text.Trim();
            var catId = CbCategory.SelectedItem is ComboBoxItem ci ? (int)(ci.Tag ?? 0) : 0;
            var products = ProductService.GetAll(search, catId, false);
            if (ChkLowStock.IsChecked == true)
                products = products.Where(p => p.IsLowStock).ToList();
            ProductGrid.ItemsSource = products;
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e) => LoadProducts();
        private void Filter_Changed(object sender, RoutedEventArgs e) => LoadProducts();

        private void ProductGrid_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (ProductGrid.SelectedItem is Product p) OpenProductDialog(p);
        }

        private void BtnEditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is Product p) OpenProductDialog(p);
        }

        private void BtnAddProduct_Click(object sender, RoutedEventArgs e) => OpenProductDialog(null);

        private void OpenProductDialog(Product? product)
        {
            var dlg = new ProductDialog(product) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadProducts();
        }

        private void BtnAdjustStock_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new StockAdjustDialog { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadProducts();
        }

        private void BtnCategories_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new CategoriesDialog { Owner = Window.GetWindow(this) };
            dlg.ShowDialog();
            LoadCategories();
        }
    }
}
