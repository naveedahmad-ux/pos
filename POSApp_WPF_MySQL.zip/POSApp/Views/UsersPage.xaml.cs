using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using POSApp.Models;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class UsersPage : Page
    {
        public UsersPage()
        {
            InitializeComponent();
            Loaded += (_, _) => LoadUsers();
        }

        private void LoadUsers() => UsersGrid.ItemsSource = UserService.GetAll();

        private void BtnAdd_Click(object sender, RoutedEventArgs e) => OpenDialog(null);

        private void UsersGrid_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (UsersGrid.SelectedItem is User u) OpenDialog(u);
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is User u) OpenDialog(u);
        }

        private void OpenDialog(User? user)
        {
            var dlg = new UserDialog(user) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadUsers();
        }
    }
}
