using System.Windows;
using System.Windows.Controls;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            TxtUserInfo.Text = $"{AuthService.CurrentUser?.FullName} ({AuthService.CurrentUser?.Role})";
            Navigate("Dashboard");

            if (!AuthService.IsAdmin)
                BtnUsers.Visibility = Visibility.Collapsed;
        }

        private void NavButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is string tag)
                Navigate(tag);
        }

        private void Navigate(string page)
        {
            switch (page)
            {
                case "Dashboard": MainFrame.Navigate(new DashboardPage()); break;
                case "Sales": MainFrame.Navigate(new SalesPage()); break;
                case "Inventory": MainFrame.Navigate(new InventoryPage()); break;
                case "Customers": MainFrame.Navigate(new CustomersPage()); break;
                case "Reports": MainFrame.Navigate(new ReportsPage()); break;
                case "Users": MainFrame.Navigate(new UsersPage()); break;
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            AuthService.Logout();
            new LoginWindow().Show();
            Close();
        }
    }
}
