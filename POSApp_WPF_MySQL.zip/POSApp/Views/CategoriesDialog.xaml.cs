using System.Windows;
using System.Windows.Controls;
using POSApp.Models;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class CategoriesDialog : Window
    {
        private Category? _selected;

        public CategoriesDialog()
        {
            InitializeComponent();
            Loaded += (_, _) => LoadCategories();
        }

        private void LoadCategories()
        {
            CatList.ItemsSource = null;
            var cats = CategoryService.GetAll();
            CatList.ItemsSource = cats;
            CatList.DisplayMemberPath = "Name";
        }

        private void CatList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CatList.SelectedItem is Category cat)
            {
                _selected = cat;
                TxtName.Text = cat.Name;
                TxtDesc.Text = cat.Description;
            }
        }

        private void BtnNew_Click(object sender, RoutedEventArgs e)
        {
            _selected = null;
            TxtName.Text = "";
            TxtDesc.Text = "";
            CatList.SelectedItem = null;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtName.Text)) { MessageBox.Show("Name is required."); return; }
            var cat = _selected ?? new Category();
            cat.Name = TxtName.Text.Trim();
            cat.Description = TxtDesc.Text.Trim();
            CategoryService.Save(cat);
            LoadCategories();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (_selected == null) { MessageBox.Show("Select a category first."); return; }
            if (MessageBox.Show("Delete this category?", "Confirm", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                CategoryService.Delete(_selected.Id);
                _selected = null;
                TxtName.Text = "";
                TxtDesc.Text = "";
                LoadCategories();
            }
        }
    }
}
