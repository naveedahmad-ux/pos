using System.Windows;
using System.Windows.Controls;
using POSApp.Models;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class UserDialog : Window
    {
        private User? _user;

        public UserDialog(User? user)
        {
            InitializeComponent();
            _user = user;
            if (user != null)
            {
                TxtTitle.Text = "Edit User";
                TxtFullName.Text = user.FullName;
                TxtUsername.Text = user.Username;
                ChkActive.IsChecked = user.IsActive;
                foreach (ComboBoxItem item in CbRole.Items)
                    if (item.Content?.ToString() == user.Role) { CbRole.SelectedItem = item; break; }
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtFullName.Text)) { MessageBox.Show("Full name is required."); return; }
            if (string.IsNullOrWhiteSpace(TxtUsername.Text)) { MessageBox.Show("Username is required."); return; }
            if (_user == null && string.IsNullOrWhiteSpace(TxtPassword.Password)) { MessageBox.Show("Password is required for new users."); return; }

            var u = _user ?? new User();
            u.FullName = TxtFullName.Text.Trim();
            u.Username = TxtUsername.Text.Trim();
            u.Role = (CbRole.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Cashier";
            u.IsActive = ChkActive.IsChecked == true;

            var pass = TxtPassword.Password;
            UserService.Save(u, string.IsNullOrWhiteSpace(pass) ? null : pass);
            DialogResult = true;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
    }
}
