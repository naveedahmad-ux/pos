using System.Windows.Controls;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class DashboardPage : Page
    {
        public DashboardPage()
        {
            InitializeComponent();
            Loaded += (_, _) => LoadData();
        }

        private void LoadData()
        {
            TxtDate.Text = DateTime.Now.ToString("dddd, MMMM dd, yyyy");

            var stats = ReportService.GetDashboardStats();
            TxtTodaySales.Text = stats.TodaySales.ToString("C");
            TxtTodayTx.Text = $"{stats.TodayTransactions} transactions";
            TxtMonthSales.Text = stats.MonthSales.ToString("C");
            TxtTotalProducts.Text = stats.TotalProducts.ToString();
            TxtLowStock.Text = stats.LowStockCount.ToString();

            // Weekly chart
            var maxSale = stats.WeeklySales.Count > 0 ? stats.WeeklySales.Max(x => x.Amount) : 1;
            var chartItems = stats.WeeklySales.Select(x => new
            {
                Day = x.Date,
                BarHeight = maxSale > 0 ? (double)(x.Amount / maxSale * 130) : 5,
                AmountStr = x.Amount.ToString("C0")
            }).ToList();
            WeeklyChart.ItemsSource = chartItems;

            // Top products
            var topItems = stats.TopProducts.Select(x => new { Name = x.Product, Qty = x.Qty + " sold" }).ToList();
            TopProductsList.ItemsSource = topItems;
        }
    }
}
