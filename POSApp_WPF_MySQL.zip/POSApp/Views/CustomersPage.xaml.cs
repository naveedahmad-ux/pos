using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using POSApp.Models;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class CustomersPage : Page
    {
        public CustomersPage()
        {
            InitializeComponent();
            Loaded += (_, _) => LoadCustomers();
        }

        private void LoadCustomers(string search = "")
        {
            CustomerGrid.ItemsSource = CustomerService.GetAll(search);
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e) => LoadCustomers(TxtSearch.Text);
        private void TxtSearch_KeyDown(object sender, KeyEventArgs e) { if (e.Key == Key.Enter) LoadCustomers(TxtSearch.Text); }
        private void BtnAdd_Click(object sender, RoutedEventArgs e) => OpenDialog(null);

        private void CustomerGrid_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (CustomerGrid.SelectedItem is Customer c) OpenDialog(c);
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is Customer c) OpenDialog(c);
        }

        private void OpenDialog(Customer? customer)
        {
            var dlg = new CustomerDialog(customer) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadCustomers(TxtSearch.Text);
        }
    }
}
