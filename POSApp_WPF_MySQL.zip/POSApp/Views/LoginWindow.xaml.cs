using System.Windows;
using System.Windows.Input;
using POSApp.Data;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            DoLogin();
        }

        private void TxtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter) DoLogin();
        }

        private void DoLogin()
        {
            TxtError.Visibility = Visibility.Collapsed;

            try
            {
                DatabaseManager.Initialize(TxtServer.Text, TxtDatabase.Text,
                    TxtDbUser.Text, TxtDbPass.Password, TxtPort.Text);
                DatabaseManager.CreateSchema();
            }
            catch (Exception ex)
            {
                TxtError.Text = "DB connection failed: " + ex.Message;
                TxtError.Visibility = Visibility.Visible;
                return;
            }

            var user = AuthService.Login(TxtUsername.Text, TxtPassword.Password);
            if (user == null)
            {
                TxtError.Text = "Invalid username or password.";
                TxtError.Visibility = Visibility.Visible;
                return;
            }

            var main = new MainWindow();
            main.Show();
            Close();
        }
    }
}
