using System.Windows;
using POSApp.Models;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class ProductDialog : Window
    {
        private Product? _product;

        public ProductDialog(Product? product)
        {
            InitializeComponent();
            _product = product;

            var categories = CategoryService.GetAll();
            categories.Insert(0, new Category { Id = 0, Name = "(No Category)" });
            CbCategory.ItemsSource = categories;

            if (product != null)
            {
                TxtTitle.Text = "Edit Product";
                TxtName.Text = product.Name;
                TxtBarcode.Text = product.Barcode;
                TxtCostPrice.Text = product.CostPrice.ToString();
                TxtSalePrice.Text = product.SalePrice.ToString();
                TxtStock.Text = product.StockQuantity.ToString();
                TxtLowStock.Text = product.LowStockThreshold.ToString();
                ChkActive.IsChecked = product.IsActive;
                CbCategory.SelectedValue = product.CategoryId ?? 0;
                foreach (System.Windows.Controls.ComboBoxItem item in CbUnit.Items)
                    if (item.Content?.ToString() == product.Unit) { CbUnit.SelectedItem = item; break; }
            }
            else
            {
                CbCategory.SelectedIndex = 0;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtName.Text)) { MessageBox.Show("Product name is required."); return; }
            if (!decimal.TryParse(TxtCostPrice.Text, out decimal cost)) { MessageBox.Show("Invalid cost price."); return; }
            if (!decimal.TryParse(TxtSalePrice.Text, out decimal sale)) { MessageBox.Show("Invalid sale price."); return; }

            var product = _product ?? new Product();
            product.Name = TxtName.Text.Trim();
            product.Barcode = string.IsNullOrWhiteSpace(TxtBarcode.Text) ? null : TxtBarcode.Text.Trim();
            product.CostPrice = cost;
            product.SalePrice = sale;
            product.StockQuantity = int.TryParse(TxtStock.Text, out int s) ? s : 0;
            product.LowStockThreshold = int.TryParse(TxtLowStock.Text, out int ls) ? ls : 10;
            product.IsActive = ChkActive.IsChecked == true;
            product.CategoryId = CbCategory.SelectedValue is int cid && cid > 0 ? cid : null;
            product.Unit = (CbUnit.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content?.ToString() ?? "pcs";

            try
            {
                ProductService.Save(product);
                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving product: " + ex.Message);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
    }
}
