using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using POSApp.Models;
using POSApp.Services;

namespace POSApp.Views
{
    public partial class SalesPage : Page
    {
        private ObservableCollection<CartItem> _cart = new();
        private bool _updating = false;

        public SalesPage()
        {
            InitializeComponent();
            Loaded += (_, _) => Initialize();
        }

        private void Initialize()
        {
            TxtInvoice.Text = "Invoice: " + SaleService.GenerateInvoiceNumber();
            CartGrid.ItemsSource = _cart;
            LoadCategories();
            LoadProducts();
            LoadCustomers();
        }

        private void LoadCategories()
        {
            var cats = CategoryService.GetAll();
            CbCategory.Items.Clear();
            CbCategory.Items.Add(new ComboBoxItem { Content = "All Categories", Tag = 0 });
            foreach (var c in cats)
                CbCategory.Items.Add(new ComboBoxItem { Content = c.Name, Tag = c.Id });
            CbCategory.SelectedIndex = 0;
        }

        private void LoadProducts(string search = "", int catId = 0)
        {
            ProductsPanel.ItemsSource = ProductService.GetAll(search, catId);
        }

        private void LoadCustomers()
        {
            var customers = new List<dynamic> { new { Id = (int?)null, Name = "Walk-in Customer" } };
            foreach (var c in CustomerService.GetAll())
                customers.Add(new { Id = (int?)c.Id, Name = $"{c.Name} ({c.Phone})" });
            CbCustomer.ItemsSource = customers;
            CbCustomer.SelectedIndex = 0;
        }

        private void TxtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                var product = ProductService.GetByBarcode(TxtSearch.Text.Trim());
                if (product != null) AddToCart(product);
                else BtnSearch_Click(null, null);
            }
        }

        private void BtnSearch_Click(object? sender, RoutedEventArgs? e)
        {
            var catId = CbCategory.SelectedItem is ComboBoxItem ci ? (int)(ci.Tag ?? 0) : 0;
            LoadProducts(TxtSearch.Text.Trim(), catId);
        }

        private void CbCategory_SelectionChanged(object sender, SelectionChangedEventArgs e) => BtnSearch_Click(null, null);

        private void ProductCard_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is Product p)
                AddToCart(p);
        }

        private void AddToCart(Product p)
        {
            if (p.StockQuantity <= 0) { MessageBox.Show("Product out of stock!"); return; }
            var existing = _cart.FirstOrDefault(x => x.ProductId == p.Id);
            if (existing != null)
            {
                if (existing.Quantity >= p.StockQuantity) { MessageBox.Show("Not enough stock!"); return; }
                existing.Quantity++;
                CartGrid.Items.Refresh();
            }
            else
                _cart.Add(new CartItem { ProductId = p.Id, ProductName = p.Name, UnitPrice = p.SalePrice, Quantity = 1, Unit = p.Unit });
            UpdateTotals();
        }

        private void RemoveItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is CartItem item)
            {
                _cart.Remove(item);
                UpdateTotals();
            }
        }

        private void CartQty_Changed(object sender, TextChangedEventArgs e)
        {
            if (_updating) return;
            if (sender is TextBox tb && tb.Tag is CartItem item && int.TryParse(tb.Text, out int qty) && qty > 0)
            {
                item.Quantity = qty;
                CartGrid.Items.Refresh();
                UpdateTotals();
            }
        }

        private void TxtDiscount_Changed(object sender, TextChangedEventArgs e) => UpdateTotals();
        private void TxtTax_Changed(object sender, TextChangedEventArgs e) => UpdateTotals();

        private void TxtAmountPaid_Changed(object sender, TextChangedEventArgs e)
        {
            if (decimal.TryParse(TxtAmountPaid.Text, out decimal paid))
            {
                var total = GetTotal();
                TxtChange.Text = Math.Max(0, paid - total).ToString("N2");
            }
        }

        private decimal GetTotal()
        {
            var sub = _cart.Sum(x => x.Subtotal);
            decimal.TryParse(TxtDiscount.Text, out decimal disc);
            decimal.TryParse(TxtTax.Text, out decimal taxPct);
            var tax = (sub - disc) * taxPct / 100;
            return sub - disc + tax;
        }

        private void UpdateTotals()
        {
            _updating = true;
            var sub = _cart.Sum(x => x.Subtotal);
            decimal.TryParse(TxtDiscount.Text, out decimal disc);
            decimal.TryParse(TxtTax.Text, out decimal taxPct);
            var tax = (sub - disc) * taxPct / 100;
            var total = sub - disc + tax;
            TxtSubtotal.Text = sub.ToString("C");
            TxtTotal.Text = total.ToString("C");
            if (decimal.TryParse(TxtAmountPaid.Text, out decimal paid))
                TxtChange.Text = Math.Max(0, paid - total).ToString("N2");
            _updating = false;
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            _cart.Clear();
            TxtInvoice.Text = "Invoice: " + SaleService.GenerateInvoiceNumber();
            UpdateTotals();
        }

        private void BtnProcessSale_Click(object sender, RoutedEventArgs e)
        {
            if (!_cart.Any()) { MessageBox.Show("Cart is empty!"); return; }
            if (!decimal.TryParse(TxtAmountPaid.Text, out decimal paid) || paid <= 0)
            { MessageBox.Show("Please enter amount paid."); return; }

            var total = GetTotal();
            if (paid < total) { MessageBox.Show("Amount paid is less than total!"); return; }

            decimal.TryParse(TxtDiscount.Text, out decimal disc);
            decimal.TryParse(TxtTax.Text, out decimal taxPct);
            var sub = _cart.Sum(x => x.Subtotal);
            var tax = (sub - disc) * taxPct / 100;

            var invoiceNo = TxtInvoice.Text.Replace("Invoice: ", "");
            var sale = new Sale
            {
                InvoiceNumber = invoiceNo,
                UserId = AuthService.CurrentUser!.Id,
                Subtotal = sub,
                DiscountAmount = disc,
                TaxAmount = tax,
                TotalAmount = total,
                AmountPaid = paid,
                Change = paid - total,
                PaymentMethod = (CbPayment.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Cash"
            };

            try
            {
                SaleService.ProcessSale(sale, _cart.ToList());
                MessageBox.Show($"Sale processed!\nInvoice: {invoiceNo}\nTotal: {total:C}\nChange: {sale.Change:C}",
                    "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                BtnClear_Click(null, null);
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
